import {Component} from "@angular/core";

@Component({
  selector: 'app-dashboard-component',
  template: '<div>Dashboard start </div>',
})
export class DashboardComponent {


};
